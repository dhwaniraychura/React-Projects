import {
  Box, Typography, Paper, Grid, Button,
  Avatar, Chip, Divider, Container
} from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import LogoutIcon from "@mui/icons-material/Logout"
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined"
import { useAuth } from "../contexts/AuthContext"
import { useNavigate, Link } from "react-router-dom"

export default function Dashboard() {
  const { currentUser, logout } = useAuth()
  const navigate = useNavigate()

  async function handleLogout() {
    await logout()
    navigate("/login")
  }

  return (
    <Box minHeight="100vh" sx={{ background: "#f4f6f8", py: 5 }}>
      <Container maxWidth="md">
        <Box display="flex" alignItems="center" gap={1} mb={3}>
          <DashboardOutlinedIcon sx={{ color: "#1976d2" }} />
          <Typography variant="h5" fontWeight={700} color="text.primary">Dashboard</Typography>
        </Box>

        <Paper elevation={2} sx={{ p: 4, borderRadius: 2, mb: 3 }}>
          <Box display="flex" alignItems="center" gap={3} mb={3}>
            <Avatar
              src={currentUser.photoURL || ""}
              sx={{ width: 64, height: 64, background: "#1976d2", fontSize: "1.6rem", border: "2px solid #e3f2fd" }}
            >
              {!currentUser.photoURL && (currentUser.displayName?.charAt(0) || currentUser.email.charAt(0)).toUpperCase()}
            </Avatar>
            <Box>
              <Typography variant="h6" fontWeight={600}>
                {currentUser.displayName || "User"}
              </Typography>
              <Typography variant="body2" color="text.secondary">{currentUser.email}</Typography>
            </Box>
          </Box>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <Box sx={{ background: "#f8f9fa", border: "1px solid #e0e0e0", borderRadius: 2, p: 2 }}>
                <Typography variant="caption" color="text.secondary" display="block" mb={1}>AUTH STATUS</Typography>
                <Chip label="Authenticated" size="small" color="success" variant="outlined" />
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box sx={{ background: "#f8f9fa", border: "1px solid #e0e0e0", borderRadius: 2, p: 2 }}>
                <Typography variant="caption" color="text.secondary" display="block" mb={1}>EMAIL VERIFIED</Typography>
                <Chip
                  label={currentUser.emailVerified ? "Verified" : "Not Verified"}
                  size="small"
                  color={currentUser.emailVerified ? "success" : "warning"}
                  variant="outlined"
                />
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box sx={{ background: "#f8f9fa", border: "1px solid #e0e0e0", borderRadius: 2, p: 2 }}>
                <Typography variant="caption" color="text.secondary" display="block" mb={1}>SIGN-IN METHOD</Typography>
                <Chip label={currentUser.providerData[0]?.providerId || "email"} size="small" color="primary" variant="outlined" />
              </Box>
            </Grid>
          </Grid>
        </Paper>

        <Box display="flex" gap={2}>
          <Button
            component={Link}
            to="/profile"
            variant="contained"
            startIcon={<EditIcon />}
            sx={{ background: "#1976d2", fontWeight: 600 }}
          >
            Edit Profile
          </Button>
          <Button
            onClick={handleLogout}
            variant="outlined"
            color="error"
            startIcon={<LogoutIcon />}
          >
            Logout
          </Button>
        </Box>
      </Container>
    </Box>
  )
}