import { useState } from "react"
import {
  Box, Button, TextField, Typography, Alert,
  Divider, Paper, CircularProgress, Container
} from "@mui/material"
import GoogleIcon from "@mui/icons-material/Google"
import PersonAddOutlinedIcon from "@mui/icons-material/PersonAddOutlined"
import { useAuth } from "../contexts/AuthContext"
import { useNavigate, Link } from "react-router-dom"

export default function Register() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { register, updateUserProfile, loginWithGoogle } = useAuth()
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError("")
    setLoading(true)
    try {
      await register(email, password)
      await updateUserProfile(name, "")
      navigate("/dashboard")
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  async function handleGoogle() {
    setError("")
    try {
      await loginWithGoogle()
      navigate("/dashboard")
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <Box minHeight="100vh" display="flex" alignItems="center" justifyContent="center" sx={{ background: "#f4f6f8", py: 4 }}>
      <Container maxWidth="xs">
        <Paper elevation={2} sx={{ p: 4, borderRadius: 2 }}>
          <Box display="flex" flexDirection="column" alignItems="center" mb={3}>
            <Box sx={{ background: "#e3f2fd", borderRadius: "50%", p: 1.5, mb: 1 }}>
              <PersonAddOutlinedIcon sx={{ color: "#1976d2", fontSize: 28 }} />
            </Box>
            <Typography variant="h5" fontWeight={600} color="text.primary">Create Account</Typography>
            <Typography variant="body2" color="text.secondary" mt={0.5}>Sign up to get started</Typography>
          </Box>

          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit} display="flex" flexDirection="column" gap={2}>
            <TextField label="Full Name" value={name} onChange={e => setName(e.target.value)} required fullWidth size="medium" />
            <TextField label="Email Address" type="email" value={email} onChange={e => setEmail(e.target.value)} required fullWidth />
            <TextField label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} required fullWidth helperText="Minimum 6 characters" />
            <Button
              type="submit"
              variant="contained"
              fullWidth
              disabled={loading}
              sx={{ py: 1.2, fontWeight: 600, background: "#1976d2" }}
            >
              {loading ? <CircularProgress size={22} sx={{ color: "#fff" }} /> : "Create Account"}
            </Button>
          </Box>

          <Divider sx={{ my: 2 }}>
            <Typography variant="caption" color="text.secondary">OR</Typography>
          </Divider>

          <Button
            onClick={handleGoogle}
            fullWidth
            variant="outlined"
            startIcon={<GoogleIcon />}
            sx={{ py: 1.2, borderColor: "#dadce0", color: "#444", "&:hover": { background: "#f8f9fa" } }}
          >
            Continue with Google
          </Button>

          <Typography variant="body2" sx={{ textAlign: "center", color: "#666", mt: 2.5 }}>
            Already have an account?{" "}
            <Link to="/login" style={{ color: "#1976d2", textDecoration: "none", fontWeight: 500 }}>Sign in</Link>
          </Typography>
        </Paper>
      </Container>
    </Box>
  )
}