import { useState } from "react"
import {
  Box, Button, TextField, Typography, Alert,
  Paper, CircularProgress, Divider, Container
} from "@mui/material"
import ManageAccountsOutlinedIcon from "@mui/icons-material/ManageAccountsOutlined"
import { useAuth } from "../contexts/AuthContext"
import { useNavigate } from "react-router-dom"

export default function Profile() {
  const { currentUser, updateUserProfile, changePassword } = useAuth()
  const [name, setName] = useState(currentUser.displayName || "")
  const [photoURL, setPhotoURL] = useState(currentUser.photoURL || "")
  const [newPassword, setNewPassword] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleProfileUpdate(e) {
    e.preventDefault()
    setError("")
    setMessage("")
    setLoading(true)
    try {
      await updateUserProfile(name, photoURL)
      setMessage("Profile updated successfully!")
    } catch (err) {
      setError("Failed to update profile.")
    }
    setLoading(false)
  }

  async function handlePasswordChange(e) {
    e.preventDefault()
    setError("")
    setMessage("")
    if (newPassword.length < 6) return setError("Password must be at least 6 characters.")
    setLoading(true)
    try {
      await changePassword(newPassword)
      setMessage("Password changed successfully!")
      setNewPassword("")
    } catch (err) {
      setError("Failed to change password. Please re-login and try again.")
    }
    setLoading(false)
  }

  return (
    <Box minHeight="100vh" sx={{ background: "#f4f6f8", py: 5 }}>
      <Container maxWidth="sm">
        <Box display="flex" alignItems="center" gap={1} mb={3}>
          <ManageAccountsOutlinedIcon sx={{ color: "#1976d2" }} />
          <Typography variant="h5" fontWeight={700} color="text.primary">Edit Profile</Typography>
        </Box>

        {message && <Alert severity="success" sx={{ mb: 3 }}>{message}</Alert>}
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

        <Paper elevation={2} sx={{ p: 3, borderRadius: 2, mb: 3 }}>
          <Typography variant="subtitle1" fontWeight={600} mb={2}>Profile Information</Typography>
          <Divider sx={{ mb: 2 }} />
          <Box component="form" onSubmit={handleProfileUpdate} display="flex" flexDirection="column" gap={2}>
            <TextField label="Display Name" value={name} onChange={e => setName(e.target.value)} fullWidth />
            <TextField label="Photo URL (optional)" value={photoURL} onChange={e => setPhotoURL(e.target.value)} fullWidth />
            <Button
              type="submit"
              variant="contained"
              disabled={loading}
              sx={{ py: 1.2, fontWeight: 600, background: "#1976d2", alignSelf: "flex-start", px: 4 }}
            >
              {loading ? <CircularProgress size={20} sx={{ color: "#fff" }} /> : "Save Changes"}
            </Button>
          </Box>
        </Paper>

        <Paper elevation={2} sx={{ p: 3, borderRadius: 2, mb: 3 }}>
          <Typography variant="subtitle1" fontWeight={600} mb={2}>Change Password</Typography>
          <Divider sx={{ mb: 2 }} />
          <Box component="form" onSubmit={handlePasswordChange} display="flex" flexDirection="column" gap={2}>
            <TextField label="New Password" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} fullWidth helperText="Minimum 6 characters" />
            <Button
              type="submit"
              variant="outlined"
              disabled={loading}
              sx={{ py: 1.2, fontWeight: 600, alignSelf: "flex-start", px: 4 }}
            >
              {loading ? <CircularProgress size={20} /> : "Update Password"}
            </Button>
          </Box>
        </Paper>

        <Button onClick={() => navigate("/dashboard")} sx={{ color: "#1976d2", textTransform: "none" }}>
          ← Back to Dashboard
        </Button>
      </Container>
    </Box>
  )
}