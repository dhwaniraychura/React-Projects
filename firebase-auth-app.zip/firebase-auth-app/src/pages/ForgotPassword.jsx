import { useState } from "react"
import { Box, Button, TextField, Typography, Alert, Paper, CircularProgress, Container } from "@mui/material"
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined"
import { useAuth } from "../contexts/AuthContext"
import { Link } from "react-router-dom"

export default function ForgotPassword() {
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { resetPassword } = useAuth()

  async function handleSubmit(e) {
    e.preventDefault()
    setError("")
    setMessage("")
    setLoading(true)
    try {
      await resetPassword(email)
      setMessage("Password reset email sent! Check your inbox.")
    } catch (err) {
      setError("Failed to send reset email. Please check the email address.")
    }
    setLoading(false)
  }

  return (
    <Box minHeight="100vh" display="flex" alignItems="center" justifyContent="center" sx={{ background: "#f4f6f8", py: 4 }}>
      <Container maxWidth="xs">
        <Paper elevation={2} sx={{ p: 4, borderRadius: 2 }}>
          <Box display="flex" flexDirection="column" alignItems="center" mb={3}>
            <Box sx={{ background: "#e3f2fd", borderRadius: "50%", p: 1.5, mb: 1 }}>
              <EmailOutlinedIcon sx={{ color: "#1976d2", fontSize: 28 }} />
            </Box>
            <Typography variant="h5" fontWeight={600}>Reset Password</Typography>
            <Typography variant="body2" color="text.secondary" mt={0.5} textAlign="center">
              Enter your email and we'll send you a reset link
            </Typography>
          </Box>

          {message && <Alert severity="success" sx={{ mb: 2 }}>{message}</Alert>}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleSubmit} display="flex" flexDirection="column" gap={2}>
            <TextField label="Email Address" type="email" value={email} onChange={e => setEmail(e.target.value)} required fullWidth />
            <Button
              type="submit"
              variant="contained"
              fullWidth
              disabled={loading}
              sx={{ py: 1.2, fontWeight: 600, background: "#1976d2" }}
            >
              {loading ? <CircularProgress size={22} sx={{ color: "#fff" }} /> : "Send Reset Email"}
            </Button>
          </Box>

          <Typography variant="body2" sx={{ textAlign: "center", color: "#666", mt: 2.5 }}>
            <Link to="/login" style={{ color: "#1976d2", textDecoration: "none" }}>← Back to Login</Link>
          </Typography>
        </Paper>
      </Container>
    </Box>
  )
}