import { initializeApp } from "firebase/app"
import { getAuth, GoogleAuthProvider } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getDatabase } from "firebase/database"

const firebaseConfig = {
  apiKey: "AIzaSyBykU0F5MJ3YIVBOdpiAU396jTpCSg7iYU",
  authDomain: "fir-auth-app-1103.firebaseapp.com",
  databaseURL: "https://fir-auth-app-1103-default-rtdb.firebaseio.com",
  projectId: "fir-auth-app-1103",
  storageBucket: "fir-auth-app-1103.firebasestorage.app",
  messagingSenderId: "803166598398",
  appId: "1:803166598398:web:40cb9f9f82fb6e506721af"
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const rtdb = getDatabase(app)
export const googleProvider = new GoogleAuthProvider()