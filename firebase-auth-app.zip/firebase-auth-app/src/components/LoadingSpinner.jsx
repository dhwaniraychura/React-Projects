import { Box, CircularProgress } from "@mui/material"

export default function LoadingSpinner() {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh" sx={{ background: "#f4f6f8" }}>
      <CircularProgress sx={{ color: "#1976d2" }} />
    </Box>
  )
}