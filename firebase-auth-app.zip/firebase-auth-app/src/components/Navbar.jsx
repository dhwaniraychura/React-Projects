import { AppBar, Toolbar, Typography, Button, Box } from "@mui/material"
import LockOutlinedIcon from "@mui/icons-material/LockOutlined"
import { useNavigate, Link } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"

export default function Navbar() {
  const { currentUser, logout } = useAuth()
  const navigate = useNavigate()

  async function handleLogout() {
    await logout()
    navigate("/login")
  }

  return (
    <AppBar position="static" elevation={1} sx={{ background: "#ffffff", borderBottom: "1px solid #e0e0e0" }}>
      <Toolbar sx={{ justifyContent: "space-between" }}>
        <Box display="flex" alignItems="center" gap={1} component={Link} to="/" sx={{ textDecoration: "none" }}>
          <LockOutlinedIcon sx={{ color: "#1976d2" }} />
          <Typography variant="h6" sx={{ color: "#1976d2", fontWeight: 700 }}>
            AuthApp
          </Typography>
        </Box>

        <Box display="flex" gap={1}>
          {currentUser ? (
            <>
              <Button component={Link} to="/dashboard" sx={{ color: "#555" }}>Dashboard</Button>
              <Button component={Link} to="/profile" sx={{ color: "#555" }}>Profile</Button>
              <Button onClick={handleLogout} variant="outlined" color="error" size="small">Logout</Button>
            </>
          ) : (
            <>
              <Button component={Link} to="/login" sx={{ color: "#555" }}>Login</Button>
              <Button component={Link} to="/register" variant="contained" size="small" sx={{ background: "#1976d2" }}>
                Register
              </Button>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  )
}